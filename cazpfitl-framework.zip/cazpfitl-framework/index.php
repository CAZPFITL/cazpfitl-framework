<?php 

	/**
	 * SET POSITIONS
	 **/ 
	$positions = [
		"home", /* => This will be the home page!! */
		"link",
		"nofile"
	];

	include ('assets/php/functions.php');
?>