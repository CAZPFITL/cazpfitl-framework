<?php

	//OBJECT
	//PRINT - WHATSAPP
	//-----------------------------------------------
	function whatsappPrint() {

		// footerContainerPrint();

		echo '
			<div class="whatsapp-content">
				<a href="" class="link">
					<img src="assets/images/WhatsApp_Logo_1.webp" alt="WhatsApp_Logo_1" class="display">
				</a>
			</div>
			';
	};
?>

