<?php
	//STATICS
	//CONTROLLER
	//DB CONNECTION
	//-----------------------------------------------//
	//                 DB CONNECTION                 //
	// ----------------------------------------------//
//	$mysqli = new mysqli('localhost', 'root', 'root', 'academiansphp');
//	$mysqli->set_charset("utf8");
//
//	if ($mysqli->connect_error) {
//		if($_SESSION["comment_mode"] == 'yes') {
//			echo "<div>Database Conection Test Failed</div>";
//			die("Connection failed: " . $mysqli->connect_error);
//		}
//		else {
//			if($_SESSION["comment_mode"] == 'yes') {
//				echo "<div>Database Conection Test Failed</div>";
//			}
//		}
//		
//	} 
//	else {
//		if($_SESSION["comment_mode"] == 'yes') {
//			echo "<div>Database Conection Test Successfully Executed</div>";
//		}
//	}

?>